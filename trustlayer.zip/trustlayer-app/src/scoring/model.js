const { z } = require("zod");

const VERSION = "tl-linear-1.0";

const FEATURES = [
  { key: "txn_frequency_monthly", label: "Monthly transactions", min: 0, max: 60 },
  { key: "avg_monthly_volume_ngn", label: "Average monthly volume", min: 5000, max: 2000000 },
  { key: "avg_balance_stability", label: "Balance stability", min: 0, max: 1 },
  { key: "airtime_topup_regularity", label: "Airtime top-up regularity", min: 0, max: 1 },
  { key: "bill_payment_consistency", label: "Bill payment consistency", min: 0, max: 1 },
  { key: "savings_ratio", label: "Savings ratio", min: 0, max: 1 },
  { key: "txn_volume_growth_3m", label: "Transaction growth (3 months)", min: -0.9, max: 2 },
  { key: "months_of_history", label: "Months of history", min: 1, max: 36 },
];

const FeatureSchema = z.object(
  Object.fromEntries(FEATURES.map((f) => [f.key, z.number().min(f.min).max(f.max)]))
);

const clamp = (n) => Math.max(300, Math.min(850, Math.round(n)));

// Transparent, reproducible baseline: the number that gets hashed onchain must be auditable.
function baseScore(f) {
  const t =
    f.txn_frequency_monthly * 3.5 +
    Math.log1p(f.avg_monthly_volume_ngn) * 14 +
    f.avg_balance_stability * 180 +
    f.airtime_topup_regularity * 120 +
    f.bill_payment_consistency * 220 +
    f.savings_ratio * 150 +
    f.txn_volume_growth_3m * 60 +
    f.months_of_history * 2.5;
  return clamp(300 + (t / 1050) * 550);
}

function drivers(f) {
  return FEATURES.map((d) => {
    const pct = (f[d.key] - d.min) / (d.max - d.min);
    return { feature: d.label, percentile: Math.round(pct * 100), direction: pct > 0.5 ? "helped" : "hurt", strength: Math.abs(pct - 0.5) };
  })
    .sort((a, b) => b.strength - a.strength)
    .slice(0, 3)
    .map(({ strength, ...rest }) => rest);
}

// Cheap consistency checks that are handed to the AI analyst as extra context.
function ruleFlags(f) {
  const flags = [];
  if (f.avg_monthly_volume_ngn > 1_000_000 && f.txn_frequency_monthly < 5) flags.push("High volume with very few transactions");
  if (f.months_of_history < 3 && f.txn_volume_growth_3m > 1.5) flags.push("Rapid growth on a very short history");
  if (f.savings_ratio > 0.6 && f.avg_balance_stability < 0.2) flags.push("Savings ratio inconsistent with balance stability");
  return flags;
}

const loanLimit = (score, volume) => Math.round((volume * (1 + 2 * ((score - 300) / 550))) / 1000) * 1000;
const band = (s) => (s >= 740 ? "Excellent" : s >= 670 ? "Good" : s >= 580 ? "Fair" : "Building");

module.exports = { VERSION, FEATURES, FeatureSchema, clamp, baseScore, drivers, ruleFlags, loanLimit, band };
